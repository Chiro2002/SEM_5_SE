#!/usr/bin/bash

function calculate_circle_area() {
    echo "scale=2; 3.14159 * $1 * $1" | bc
}

function calculate_circle_circumference() {
    echo "scale=2; 2 * 3.14159 * $1" | bc
}

while true; do
    echo "______________ Menu: _______________"
    echo "1. Calculate area of a circle"
    echo "2. Calculate circumference of a circle"
    echo "3. Exit"

    read -p "Enter your choice: " choice

    if [ $choice -eq 1 ]; then
        read -p "Enter the radius of the circle: " radius
        if (( $(echo "$radius < 0" | bc -l) )); then
            echo "Error ! Please enter a non-negative radius."
        else
            area=$(calculate_circle_area $radius)
            echo "The area of the circle is: $area"
        fi
    elif [ $choice -eq 2 ]; then
        read -p "Enter the radius of the circle: " radius
        if (( $(echo "$radius < 0" | bc -l) )); then
            echo "Error ! Please enter a non-negative radius."
        else
            circumference=$(calculate_circle_circumference $radius)
            echo "The circumference of the circle is: $circumference"
        fi
    elif [ $choice -eq 3 ]; then
        echo "Exiting the program."
        break
    else
        echo "Error ! Invalid choice. Please select a valid option."
    fi
done
