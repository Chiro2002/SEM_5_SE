#!/usr/bin/bash

while true; do
    echo "______________ Menu: _______________"
    echo "1. Calculate profit or loss"
    echo "2. Check for negative numbers"
    echo "3. Exit"

    read -p "Enter your choice: " choice

    if [ "$choice" -eq 1 ]; then
        read -p "Enter the cost price: " CP
        read -p "Enter the selling price: " SP

        if (( CP < 0 || SP < 0 )); then
            echo "Error! Please enter non-negative values for cost price and selling price."
        elif (( CP > SP )); then
            echo "You have made a loss of: $(bc <<< "$CP - $SP")"
        elif (( SP > CP )); then
            echo "You have made a profit of: $(bc <<< "$SP - $CP")"
        else
            echo "You have made neither profit nor loss"
        fi
    elif [ "$choice" -eq 2 ]; then
        read -p "Enter a number: " num
        if (( num < 0 )); then
            echo "You have entered a negative number."
        else
            echo "You have entered a non-negative number."
        fi
    elif [ "$choice" -eq 3 ]; then
        echo "Exiting the program."
        break
    else
        echo "Invalid choice. Please select a valid option."
    fi
done
