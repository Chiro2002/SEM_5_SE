#!/usr/bin/bash

factorial() {
    n="$1"
    if (( n < 0 )); then
        echo "Factorial is not defined for negative numbers"
    elif (( n == 0 )); then
        echo 1
    else
        result=1
        for (( i = 1; i <= n; i++ )); do
            result=$(( result * i ))
        done
        echo "$result"
    fi
}

while true; do
    echo -e "\nMenu:"
    echo "1. Calculate Factorial"
    echo "2. Exit"

    read -p "Enter your choice (1/2): " choice

    if [ "$choice" = "1" ]; then
        read -p "Enter a non-negative integer: " num
        if [[ "$num" =~ ^[0-9]+$ ]]; then
            echo "The factorial of $num is $(factorial $num)"
        else
            echo "Invalid input. Please enter a non-negative integer."
        fi
    elif [ "$choice" = "2" ]; then
        echo "Exiting the program."
        break
    else
        echo "Invalid choice. Please enter 1 or 2."
    fi
done
