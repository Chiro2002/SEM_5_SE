#!/usr/bin/bash

is_prime() {
    number="$1"
    if (( number <= 1 )); then
        return 1  # False
    fi

    for ((i = 2; i <= number / 2; i++)); do
        if (( number % i == 0 )); then
            return 1  # False
        fi
    done

    return 0  # True
}

while true; do
    echo "Menu:"
    echo "1. Check if a number is prime"
    echo "2. Exit"

    read -p "Enter your choice: " choice

    if [ "$choice" -eq 1 ]; then
        read -p "Enter your number: " number
        if is_prime "$number"; then
            echo "$number is a prime number."
        else
            echo "$number is not a prime number."
        fi
    elif [ "$choice" -eq 2 ]; then
        echo "Exiting the program."
        break
    else
        echo "Invalid choice. Please select a valid option."
    fi
done
