#!/usr/bin/bash

print_numeric_pyramid() {
    rows="$1"
    for ((i = 1; i <= rows; i++)); do
        for ((j = 1; j <= i; j++)); do
            echo -n "$j "
        done
        echo
    done
}

print_special_character_pyramid() {
    rows="$1"
    character="$2"
    for ((i = 1; i <= rows; i++)); do
        spaces=$((rows - i))
        characters=$((2 * i - 1))
        printf "%${spaces}s%s\n" "" "$character$character$character"
    done
}

while true; do
    echo -e "\nMenu:"
    echo "1. Print Numeric Pyramid"
    echo "2. Print Special Character Pyramid"
    echo "3. Print Combined Pyramid"
    echo "4. Exit"

    read -p "Enter your choice (1/2/3/4): " choice

    if [ "$choice" -eq 1 ]; then
        read -p "Enter the number of rows for the numeric pyramid: " rows
        print_numeric_pyramid "$rows"
    elif [ "$choice" -eq 2 ]; then
        read -p "Enter the number of rows for the special character pyramid: " rows
        read -p "Enter the special character to use: " character
        print_special_character_pyramid "$rows" "$character"
    elif [ "$choice" -eq 3 ]; then
        read -p "Enter the number of rows for the combined pyramid: " rows
        echo "Numeric Pyramid:"
        print_numeric_pyramid "$rows"
        read -p "Enter the special character to use: " character
        echo "Special Character Pyramid:"
        print_special_character_pyramid "$rows" "$character"
    elif [ "$choice" -eq 4 ]; then
        echo "Exiting the program."
        break
    else
        echo "Invalid choice. Please enter 1, 2, 3, or 4."
    fi
done
